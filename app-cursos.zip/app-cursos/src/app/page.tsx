// Marcador temporal. La landing real se construye en la siguiente fase.
export default function Home() {
  return (
    <main className="marco" style={{ paddingBlock: "var(--e-9)" }}>
      <div className="t-folio">App Cursos</div>
      <h1 className="t-rotulo" style={{ marginTop: "var(--e-3)" }}>
        Taller de Resultados
      </h1>
      <div className="perforacion" style={{ maxWidth: 420 }} />
      <p className="t-lectura">
        Proyecto inicializado. El Design System está cargado y verificado.
        Nada de producto construido todavía.
      </p>
      <p style={{ marginTop: "var(--e-6)" }}>
        <a className="btn btn-primario" href="/dev/tokens">
          Ver la verificación de tokens
        </a>
      </p>
    </main>
  );
}
