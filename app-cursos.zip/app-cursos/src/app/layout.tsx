// ============================================================================
// APP CURSOS — "Taller de Resultados"
// Destino: src/app/layout.tsx
// ----------------------------------------------------------------------------
// next/font descarga y sirve las fuentes DESDE TU PROPIO DOMINIO en build time.
// No hay petición a fonts.googleapis.com en runtime: cero salto de red de
// terceros, cero CLS, mejor LCP en conexiones móviles mexicanas.
// ============================================================================

import type { Metadata, Viewport } from "next";
import { Archivo, Newsreader } from "next/font/google";
import "./globals.css";

// Eje de ancho variable (wdth 62–125). Es lo que habilita la regla de los
// tres anchos del Design System: 118 rótulo / 100 interfaz / 88 folio.
const archivo = Archivo({
  subsets: ["latin", "latin-ext"],
  axes: ["wdth"],
  weight: "variable",
  display: "swap",
  variable: "--fuente-titular",
});

// Eje de tamaño óptico real (opsz 6–72). Corrige el grosor del asta según
// el tamaño de composición. Es la razón por la que el texto largo cansa menos.
const newsreader = Newsreader({
  subsets: ["latin", "latin-ext"],
  axes: ["opsz"],
  weight: "variable",
  display: "swap",
  variable: "--fuente-cuerpo",
});

export const metadata: Metadata = {
  title: "App Cursos",
  description:
    "Cursos prácticos de IA para dueños de negocio. Entras con un problema, sales con una pieza terminada.",
};

export const viewport: Viewport = {
  themeColor: "#F2EEE4", // papel — la barra del navegador móvil también es papel
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="es-MX" className={`${archivo.variable} ${newsreader.variable}`}>
      <body>{children}</body>
    </html>
  );
}
