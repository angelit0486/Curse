// ============================================================================
// APP CURSOS — Página de verificación de tokens
// Destino: src/app/dev/tokens/page.tsx     →     ruta /dev/tokens
// ----------------------------------------------------------------------------
// TEMPORAL. No es producto. Se borra antes del lanzamiento.
// Solo existe para verificar color, tipografía, superficies, sello y
// perforación renderizados de verdad, en el dispositivo real.
// ============================================================================

"use client";

import { useState } from "react";

export const dynamic = "force-static";

const PAPELES = [
  ["papel", "#F2EEE4", "Fondo global"],
  ["papel-hundido", "#E7E1D3", "Zonas rebajadas"],
  ["lienzo", "#FBF9F4", "Superficie elevada"],
  ["lienzo-tinte", "#F7F3E9", "Filas alternas"],
];

const TINTAS = [
  ["tinta", "#1E2A1C", "Texto principal"],
  ["tinta-media", "#4C5847", "Texto secundario"],
  ["tinta-tenue", "#78826F", "Deshabilitado, ≥16px"],
  ["tinta-inversa", "#F4F1E7", "Sobre musgo o cobre"],
];

const MUSGO = [
  ["musgo-900", "#22301F", "Pie, barra de aprendizaje"],
  ["musgo-700", "#31432C", "Hover"],
  ["musgo-600", "#3E5236", "MARCA · botón primario"],
  ["musgo-500", "#4B6141", "Presionado"],
  ["musgo-300", "#94A288", "Iconografía inactiva"],
  ["musgo-100", "#DFE5D7", "Fondo suave"],
];

const COBRE = [
  ["cobre-700", "#7E3714", "Hover cobre"],
  ["cobre-600", "#9C481C", "Sello · precio · destacado"],
  ["cobre-400", "#C2703F", "Arco de progreso"],
  ["cobre-100", "#F2DFCF", "Fondo de precio"],
  ["patina", "#6E7F5E", "Perforación"],
];

const ESTADOS = [
  ["logrado", "#3E5236", "Completado"],
  ["atencion", "#8A5D0C", "Quiz reprobado"],
  ["falla", "#8E2A20", "Error"],
  ["bloqueado", "#8C8878", "Sin acceso"],
];

function Muestra({ nombre, hex, uso }: { nombre: string; hex: string; uso: string }) {
  return (
    <div style={{ display: "flex", gap: "var(--e-4)", alignItems: "center" }}>
      <div
        style={{
          width: 52,
          height: 52,
          flex: "none",
          background: `var(--${nombre})`,
          borderRadius: "var(--r-placa)",
          borderTop: "1px solid var(--linea-luz)",
          borderLeft: "1px solid var(--linea)",
          borderRight: "1px solid var(--linea)",
          borderBottom: "1px solid var(--linea-sombra)",
        }}
      />
      <div>
        <div className="t-interfaz">{nombre}</div>
        <div className="t-dato" style={{ color: "var(--tinta-tenue)" }}>
          {hex} · {uso}
        </div>
      </div>
    </div>
  );
}

function Bloque({ titulo, datos }: { titulo: string; datos: string[][] }) {
  return (
    <section style={{ marginBottom: "var(--e-8)" }}>
      <h2 className="t-titulo-3" style={{ marginBottom: "var(--e-5)" }}>{titulo}</h2>
      <div
        style={{
          display: "grid",
          gap: "var(--e-5)",
          gridTemplateColumns: "repeat(auto-fill, minmax(260px, 1fr))",
        }}
      >
        {datos.map(([n, h, u]) => (
          <Muestra key={n} nombre={n} hex={h} uso={u} />
        ))}
      </div>
    </section>
  );
}

export default function TokensPage() {
  const [sellado, setSellado] = useState(false);

  return (
    <main className="marco" style={{ paddingBlock: "var(--e-9)" }}>
      <header style={{ marginBottom: "var(--e-9)" }}>
        <div className="t-folio">DEV · TOKENS</div>
        <h1 className="t-rotulo" style={{ marginTop: "var(--e-3)" }}>
          Taller de Resultados
        </h1>
        <p className="t-lectura-guia" style={{ marginTop: "var(--e-5)", color: "var(--tinta-media)" }}>
          Página temporal de verificación. Aquí se comprueba que el sistema se ve
          como está escrito, en el dispositivo real y no en una captura.
        </p>
      </header>

      {/* --- Prueba de diacríticos: la verificación obligatoria del §4.1 --- */}
      <section className="superficie" style={{ marginBottom: "var(--e-9)" }}>
        <div className="t-folio">Prueba de acentos</div>
        <p className="t-titulo-1" style={{ marginTop: "var(--e-4)" }}>
          Ñoño, ¿cuánto ahorrás? — 5 horas
        </p>
        <div className="perforacion" />
        <p className="t-lectura">
          Ñoño, ¿cuánto ahorrás? — 5 horas · 3.400 días. Revisa la apertura de la
          interrogación, la tilde sobre la á, el ojo de la ñ y el guion largo. Si
          algo se ve pegado o desalineado, se reporta antes de construir un solo
          componente.
        </p>
      </section>

      <Bloque titulo="Papeles" datos={PAPELES} />
      <Bloque titulo="Tintas" datos={TINTAS} />
      <Bloque titulo="Musgo — estructura y acción" datos={MUSGO} />
      <Bloque titulo="Cobre — recompensa y venta" datos={COBRE} />
      <Bloque titulo="Estados" datos={ESTADOS} />

      {/* --- Escala tipográfica --- */}
      <section style={{ marginBottom: "var(--e-9)" }}>
        <h2 className="t-titulo-3" style={{ marginBottom: "var(--e-5)" }}>
          Escala tipográfica
        </h2>
        <div className="superficie">
          <div className="t-folio">wdth 118</div>
          <p className="t-rotulo">Recupera 5 horas</p>
          <div className="perforacion" />
          <div className="t-folio">wdth 118</div>
          <p className="t-titulo-1">Consigue clientes con IA</p>
          <div className="perforacion" />
          <div className="t-folio">wdth 100</div>
          <p className="t-titulo-2">Módulo 2 · Tu ficha de Google</p>
          <p className="t-titulo-3" style={{ marginTop: "var(--e-4)" }}>
            Reseñas: cómo pedirlas y cómo responderlas
          </p>
          <div className="perforacion" />
          <div className="t-folio">opsz 19 · máximo 66ch</div>
          <p className="t-lectura" style={{ marginTop: "var(--e-3)" }}>
            Cuando alguien en tu ciudad necesita lo que vendes, casi nunca abre
            Instagram. Escribe en Google. Dos negocios, mismo precio, misma
            distancia: uno tiene 4 reseñas, el otro 47. No hace falta explicar
            cuál eligen.
          </p>
        </div>
      </section>

      {/* --- Botones --- */}
      <section style={{ marginBottom: "var(--e-9)" }}>
        <h2 className="t-titulo-3" style={{ marginBottom: "var(--e-5)" }}>
          Botones — presiónalos, se hunden
        </h2>
        <div style={{ display: "flex", flexWrap: "wrap", gap: "var(--e-4)" }}>
          <button className="btn btn-primario">Empezar el curso</button>
          <button className="btn btn-secundario">Ver el temario</button>
          <button className="btn btn-fantasma">Cancelar</button>
          <button className="btn btn-falla">Borrar mi cuenta</button>
          <button className="btn btn-primario" disabled>
            Sin acceso
          </button>
        </div>
      </section>

      {/* --- El sello --- */}
      <section style={{ marginBottom: "var(--e-9)" }}>
        <h2 className="t-titulo-3" style={{ marginBottom: "var(--e-5)" }}>
          El sello — la firma del producto
        </h2>
        <div className="superficie">
          <div className="rejilla">
            <div className="carril">
              <div className="t-folio">M02·L07</div>
              <div
                key={String(sellado)}
                className={sellado ? "sello sello-logrado" : "sello"}
                aria-hidden
              >
                {sellado ? "✓" : ""}
              </div>
            </div>
            <div>
              <h3 className="t-titulo-3">Tu ficha de Google, lista hoy</h3>
              <p className="t-lectura" style={{ marginTop: "var(--e-3)" }}>
                Vas a salir con esto: tu negocio en Google Maps con la
                información completa, las fotos y la descripción escritas.
              </p>
              <div className="perforacion" />
              <button
                className="btn btn-primario"
                onClick={() => setSellado((v) => !v)}
              >
                {sellado ? "Quitar el sello" : "Marcar como completada"}
              </button>
              <p className="t-dato" style={{ marginTop: "var(--e-4)", color: "var(--tinta-tenue)" }}>
                La única animación no disparada por el usuario en todo el
                producto. Rotación fija de −7°.
              </p>
            </div>
            <div />
          </div>
        </div>
      </section>

      {/* --- Progreso, campos, insignias --- */}
      <section style={{ marginBottom: "var(--e-9)" }}>
        <h2 className="t-titulo-3" style={{ marginBottom: "var(--e-5)" }}>
          Progreso, campos e insignias
        </h2>
        <div className="superficie">
          <div className="t-dato">Consigue clientes con IA · 9 de 15 lecciones</div>
          <div className="pista" style={{ marginTop: "var(--e-3)" }}>
            <span style={{ width: "60%" }} />
          </div>

          <div className="perforacion" />

          <label className="t-interfaz" htmlFor="correo">Tu correo</label>
          <input
            id="correo"
            className="campo"
            style={{ marginTop: "var(--e-3)" }}
            placeholder="nombre@negocio.mx"
          />

          <div className="perforacion" />

          <div style={{ display: "flex", flexWrap: "wrap", gap: "var(--e-3)" }}>
            <span className="insignia">Principiante</span>
            <span className="insignia insignia-precio">$1,490 MXN</span>
            <span className="insignia insignia-estado insignia-logrado">Completado</span>
            <span className="insignia insignia-estado insignia-bloqueado">Bloqueado</span>
            <span className="insignia insignia-estado">Gratis</span>
          </div>
        </div>
      </section>

      <p className="t-dato" style={{ color: "var(--tinta-tenue)", paddingBottom: "var(--e-9)" }}>
        Ruta temporal. Eliminar antes del lanzamiento.
      </p>
    </main>
  );
}
